#!/usr/bin/env python3
"""Lab patch for NAI 2.8.1 nai-api (/app/nai-iep): append "amd-gpu-passthrough" to
enum.AcceleratorSupportedPlatformTypes (the create-endpoint `validAcceleratorSupportedPlatforms`
validator). The slice's 3-entry backing array is followed by 16 bytes of alignment padding,
so the 4th string header goes there and len/cap become 4. NvidiaGPUPlatforms is untouched.
Usage: patch-nai-api-amdgpu.py <in> <out>"""
import struct, sys
SECTIONS = [(0x893eec0, 0x853eec0, 0x7b0f2),    # .data
            (0x3a62000, 0x3662000, 0x1496779)]  # .rodata
def off(va):
    for vs, fo, sz in SECTIONS:
        if vs <= va < vs + sz:
            return va - vs + fo
    raise SystemExit(f"va {va:#x} outside known sections")
SLICE_HDR, ARRAY, AMD = 0x894a2e0, 0x898f340, b"amd-gpu-passthrough"
b = bytearray(open(sys.argv[1], "rb").read())
ptr, ln, cap = struct.unpack_from("<QQQ", b, off(SLICE_HDR))
want = [b"nvidia-gpu-passthrough", b"nvidia-vgpu", b"nvidia-mig"]
got = []
for i in range(3):
    p, l = struct.unpack_from("<QQ", b, off(ARRAY) + 16 * i)
    got.append(bytes(b[off(p):off(p) + l]))
if (ptr, ln, cap) != (ARRAY, 3, 3) or got != want:
    raise SystemExit(f"unexpected layout: {(hex(ptr), ln, cap)} {got}")
slot = off(ARRAY) + 48
if any(b[slot:slot + 16]):
    raise SystemExit("padding after array is not zero")
amd_off = b.find(AMD, off(0x3a62000))
amd_va = amd_off - 0x3662000 + 0x3a62000
struct.pack_into("<QQ", b, slot, amd_va, len(AMD))
struct.pack_into("<QQ", b, off(SLICE_HDR) + 8, 4, 4)
open(sys.argv[2], "wb").write(b)
print(f"patched: 4th platform -> {amd_va:#x} ({AMD.decode()})")
