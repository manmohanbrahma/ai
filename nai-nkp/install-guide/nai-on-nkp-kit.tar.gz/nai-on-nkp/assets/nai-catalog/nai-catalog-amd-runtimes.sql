-- nai-on-nkp (moded stack, NAI 2.8.1): offer amd-gpu-passthrough for validated catalog models that have an
-- NVIDIA passthrough vLLM runtime, except ones tied to NVIDIA-only software:
--   NVIDIA-Nemotron-3-Ultra (FlashInfer env), unsloth *-bnb-4bit (bitsandbytes, CUDA-only in vLLM).
-- Copies the NVIDIA sizing/args, swaps in the ROCm vLLM image. NOT AMD-validated by Nutanix.
-- Idempotent; re-apply after NAI upgrades / catalog refresh.
-- Revert: DELETE FROM runtimes WHERE name='vllm-amd-gpu-passthrough' AND image='__ROCM_IMAGE__';
BEGIN;
INSERT INTO runtimes (catalog_id, name, image, cpu, ram, accelerator_memory, additional_properties, model_capabilities)
SELECT r.catalog_id, 'vllm-amd-gpu-passthrough', '__ROCM_IMAGE__',
       r.cpu, r.ram, r.accelerator_memory, r.additional_properties, r.model_capabilities
FROM runtimes r JOIN catalogs c ON c.id = r.catalog_id
WHERE r.name = 'vllm-nvidia-gpu-passthrough'
  AND c.validated
  AND coalesce(r.additional_properties, '') NOT ILIKE '%FLASHINFER%'
  AND c.model_name NOT ILIKE '%bnb-4bit%'
  AND coalesce(r.additional_properties, '') NOT ILIKE '%bitsandbytes%'
ON CONFLICT (catalog_id, name) DO NOTHING;
SELECT count(*) AS amd_runtimes FROM runtimes WHERE name = 'vllm-amd-gpu-passthrough';
COMMIT;
