#!/usr/bin/env python3
"""nai-amd-shim: mutating webhook for NAI 2.8.1 endpoint pods on amd-gpu-passthrough.
nai-api always renders nvidia.com/gpu + an nvidia toleration; for pods labelled
endpoint.iep.nai.nutanix.com/platform=amd-gpu-passthrough this rewrites them to amd.com/gpu.
NAI runs the model container as nobody, so the host's video/render GIDs (owners of /dev/kfd and
/dev/dri/renderD*) are added as supplementalGroups -- the k8s form of `docker run --group-add video`."""
import base64, json, os, ssl, sys
from http.server import BaseHTTPRequestHandler, HTTPServer

NV, AMD = "nvidia.com/gpu", "amd.com/gpu"
GPU_GROUPS = [int(g) for g in os.environ.get("AMD_GPU_SUPPLEMENTAL_GROUPS", "").split(",") if g.strip()]


def esc(k):  # JSON-pointer escaping
    return k.replace("~", "~0").replace("/", "~1")


def patch_for(pod):
    ops = []
    spec = pod.get("spec", {})
    for kind in ("initContainers", "containers"):
        for i, c in enumerate(spec.get(kind) or []):
            res = c.get("resources") or {}
            for sect in ("requests", "limits"):
                vals = res.get(sect) or {}
                if NV in vals:
                    base = f"/spec/{kind}/{i}/resources/{sect}/"
                    ops.append({"op": "add", "path": base + esc(AMD), "value": vals[NV]})
                    ops.append({"op": "remove", "path": base + esc(NV)})
    tols = spec.get("tolerations") or []
    new = [t for t in tols if t.get("key") != NV]
    if len(new) != len(tols) or ops:
        if not any(t.get("key") == AMD for t in new):
            new.append({"key": AMD, "operator": "Exists", "effect": "NoSchedule"})
        ops.append({"op": "replace" if "tolerations" in spec else "add", "path": "/spec/tolerations", "value": new})
    if ops and GPU_GROUPS:
        sc = spec.get("securityContext")
        if sc is None:
            ops.append({"op": "add", "path": "/spec/securityContext", "value": {"supplementalGroups": GPU_GROUPS}})
        else:
            groups = sorted(set(sc.get("supplementalGroups") or []) | set(GPU_GROUPS))
            ops.append({"op": "add", "path": "/spec/securityContext/supplementalGroups", "value": groups})
    return ops


class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ok")

    def do_POST(self):
        review = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        req = review["request"]
        resp = {"uid": req["uid"], "allowed": True}
        try:
            ops = patch_for(req["object"])
            if ops:
                resp.update(patchType="JSONPatch", patch=base64.b64encode(json.dumps(ops).encode()).decode())
                meta = req["object"].get("metadata", {})
                print(f"mutated {req.get('namespace')}/{meta.get('generateName', meta.get('name', '?'))}: {len(ops)} ops", flush=True)
        except Exception as e:  # never block pod creation
            print(f"error: {e}", file=sys.stderr, flush=True)
        body = json.dumps({"apiVersion": "admission.k8s.io/v1", "kind": "AdmissionReview", "response": resp}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.load_cert_chain("/tls/tls.crt", "/tls/tls.key")
srv = HTTPServer(("0.0.0.0", 8443), H)
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
print("nai-amd-shim listening on :8443", flush=True)
srv.serve_forever()
