#!/usr/bin/env python3
"""Patch the NAI 2.8.1 inference UI for mixed NVIDIA + AMD GPU passthrough (lab).

UX: a single "GPU Passthrough" acceleration type. Its Accelerator Product list contains every
passthrough GPU NAI reports in cluster/info (product names come from the GPU node labels, i.e.
nvidia.com/gpu.product and beta.amd.com/gpu.product-name, nothing is hard-coded). The product
picked decides the real platform (nvidia-gpu-passthrough | amd-gpu-passthrough), which then
drives the requirements query, the default vLLM image/label and the create-endpoint payload.

nai-api 2.8.1 has no default image for amd-gpu-passthrough on non-catalog models, so for AMD the
"NAI" engine source is sent as an image override with ROCM_IMAGE (unless the catalog provides one).

Engine Source also lists extra vLLM versions per GPU vendor (custom models only; NAI rejects image
overrides for validated catalog models), read from a JSON file {platform: [{label, image}, ...]}.

Usage: patch-nai-ui-amdgpu.py <html-root> [rocm-image] [vllm-versions.json]
"""
import glob, json, os, sys

root = sys.argv[1]
ROCM_IMAGE = sys.argv[2] if len(sys.argv) > 2 else "docker.io/rocm/nai-vllm-rocm:v0.29.0-rocm10.1.0"
VERSIONS = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else {}
PLAT_CHUNK, ENTRY = "chunks/C2Xl4v4i5h2.js", "entry/CQ-U_Vo4pO.js"
NEW_PLAT, NEW_ENTRY = "chunks/C2Xl4v4i5h2-amd4.js", "entry/CQ-U_Vo4pO-amd4.js"   # cache-bust names
NV, AMD = "nvidia-gpu-passthrough", "amd-gpu-passthrough"

def sub(path, old, new):
    p = os.path.join(root, path)
    s = open(p, encoding="utf-8").read()
    if s.count(old) != 1:
        sys.exit(f"{path}: expected 1 match of {old[:70]!r}, found {s.count(old)}")
    open(p, "w", encoding="utf-8").write(s.replace(old, new))

# --- platform enum (shared chunk) ---
sub(PLAT_CHUNK,
    f"children:{{nvidiaGpuPassthrough:{{key:`{NV}`,value:`{NV}`}}}}",
    f"children:{{nvidiaGpuPassthrough:{{key:`{NV}`,value:`{NV}`}},amdGpuPassthrough:{{key:`{AMD}`,value:`{AMD}`}}}}")
sub(PLAT_CHUNK, "z.gpu.children.nvidiaGpuPassthrough.key]",
    "z.gpu.children.nvidiaGpuPassthrough.key,z.gpu.children.amdGpuPassthrough.key]")

# --- entry: helpers. __naiPP maps product -> platform (filled when products are listed);
#     __naiPlat resolves the passthrough group to the selected product's real platform.
p = os.path.join(root, ENTRY)
s = open(p, encoding="utf-8").read()
prelude = ("globalThis.__naiPP=globalThis.__naiPP||{};"
           f"globalThis.__naiIsPT=k=>k===`{NV}`||k===`{AMD}`;"
           "globalThis.__naiPlat=(k,p)=>globalThis.__naiIsPT(k)&&p&&globalThis.__naiPP[p]?globalThis.__naiPP[p]:k;"
           f"globalThis.__naiRocmImage=`{ROCM_IMAGE}`;"
           # extra engine versions: option key "img:<image>"; vendor taken from the default image of the chosen GPU
           f"globalThis.__naiVLLM={json.dumps(VERSIONS)};"
           "globalThis.__naiVersions=(e,v)=>{if(v||!e?.url)return{};"
           f"let k=e.url.includes(`rocm`)?`{AMD}`:e.tag?.includes(`gpu`)?`{NV}`:``,o={{}};"
           "(globalThis.__naiVLLM[k]||[]).forEach(x=>{o[`img:`+x.image]={key:`img:`+x.image,label:x.label}});return o};\n")
open(p, "w", encoding="utf-8").write(prelude + s)

# 1. acceleration types: AMD passthrough folds into the single "GPU Passthrough" entry (group key = NV)
sub(ENTRY, "n.set(e.platform,{key:e.platform,label:e.type,type:oo.Gpu})",
    f"n.set(e.platform===`{AMD}`?`{NV}`:e.platform,{{key:e.platform===`{AMD}`?`{NV}`:e.platform,label:e.type,type:oo.Gpu}})")
# 2. keep the group when the model supports only one vendor
sub(ENTRY, "r.has(e.key)&&(N9(e.type)?",
    f"(r.has(e.key)||e.key===`{NV}`&&r.has(`{AMD}`))&&(N9(e.type)?")
# 3. accelerator products: all passthrough GPUs (filtered per model support), remember their platform
sub(ENTRY,
    "sYe=(e,t,n,r)=>{if(!t||!r)return[];let i=new Set;if(t.nodes.forEach(e=>{Array.isArray(e.accelerators)&&e.accelerators.forEach(e=>{e.product&&e.platform===r&&i.add(e.product)})}),i.size===0)return[];let a=Array.from(i).map(e=>({key:e,label:e}));return!n||e.has(r)&&i.size>0?a:[]}",
    "sYe=(e,t,n,r)=>{if(!t||!r)return[];let i=new Set;t.nodes.forEach(o=>{Array.isArray(o.accelerators)&&o.accelerators.forEach(o=>{o.product&&(o.platform===r||globalThis.__naiIsPT(r)&&globalThis.__naiIsPT(o.platform))&&(!n||e.has(o.platform))&&(globalThis.__naiPP[o.product]=o.platform,i.add(o.product))})});return Array.from(i).map(e=>({key:e,label:e}))}")
# 4. basics step: requirements query uses the product's platform
sub(ENTRY, "b(j9(g,e,h.key))", "b(j9(g,e,globalThis.__naiPlat(h.key,e?.key)))")
# 5. config step: resolved platform for requirements + default engine image
sub(ENTRY, "b=g&&N9(g.key)?M9(_):g?.key;let x=ts(n,T9.acceleratorProduct.fieldId)",
    "b=g&&N9(g.key)?M9(_):globalThis.__naiPlat(g?.key,ts(n,T9.acceleratorProduct.fieldId)?.key);let x=ts(n,T9.acceleratorProduct.fieldId)")
sub(ENTRY, "selectedAccelerator:g,catalogRuntimes:de?.runtimes??[]",
    "selectedAccelerator:g&&{...g,key:b},catalogRuntimes:de?.runtimes??[]")
sub(ENTRY, "return i?V9(i?.image??``):{}}",
    f"return i?V9(i?.image??``):t?.key===`{AMD}`?V9(globalThis.__naiRocmImage):{{}}}}")
# 6. engine-source label shows which vLLM build will run
sub(ENTRY, "let t=`NAI${e?` (${e.tag})`:``}`",
    "let t=e?.url?.includes(`rocm`)?`AMD vLLM - ROCm (${e.tag})`:e?.tag?.includes(`gpu`)?`NAI Default - NVIDIA vLLM (${e.tag})`:`NAI${e?.tag?` (${e.tag})`:``}`")
# 7. payload: real platform; AMD + NAI source on a non-catalog model -> explicit ROCm image
#    (nai-api has no AMD default for custom models; catalog models carry their own AMD runtime and
#    nai-api rejects engineImageOverride for validated catalog models, NAI-10017)
sub(ENTRY, "o=e.acceleratorType?.type===`cpu`?M9(e.amxEnabled):e.acceleratorType?.key||``",
    "o=e.acceleratorType?.type===`cpu`?M9(e.amxEnabled):globalThis.__naiPlat(e.acceleratorType?.key,e.acceleratorProduct?.key)||``")
sub(ENTRY, "return c.advancedConfig=aXe(e),c}",
    f"if(o===`{AMD}`&&t&&!e.model?.modelDetails?.catalogId){{let r=e.defaultNAIRuntimeImage?.url?.includes(`rocm`)?e.defaultNAIRuntimeImage:V9(globalThis.__naiRocmImage);c.engineSource=`custom`,c.engineImageOverride={{name:r.url,tag:r.tag}}}}return c.advancedConfig=aXe(e),c}}")

# 8. Engine Source: stored vLLM versions for the selected GPU vendor (non-validated models only)
sub(ENTRY, "C9=e=>{let t=", "C9=(e,v)=>{let t=")
sub(ENTRY, "[Ba.custom]:{label:u(`Endpoints.importFromOtherRegistry`),key:Ba.custom}}}",
    "[Ba.custom]:{label:u(`Endpoints.importFromOtherRegistry`),key:Ba.custom},...globalThis.__naiVersions(e,v)}}")
sub(ENTRY, "H=(0,gv.useMemo)(()=>C9(y),[y])", "H=(0,gv.useMemo)(()=>C9(y,O),[y,O])")
# 9. payload: a stored version is sent as an image override (engineSource custom)
sub(ENTRY, "return c.advancedConfig=aXe(e),c}",
    "if(e.runtimeSource?.key?.startsWith(`img:`)){let r=V9(e.runtimeSource.key.slice(4));c.engineSource=`custom`,c.engineImageOverride={name:r.url,tag:r.tag}}return c.advancedConfig=aXe(e),c}")
# 10. summary pages show the option label instead of the raw key
sub(ENTRY, "value:e.runtimeSource?.key?.toUpperCase()||`-`", "value:e.runtimeSource?.label||e.runtimeSource?.key?.toUpperCase()||`-`")
sub(ENTRY, "formatter:()=>n.runtimeSource?.key?.toUpperCase()", "formatter:()=>n.runtimeSource?.label||n.runtimeSource?.key?.toUpperCase()")

# --- cache-bust: rename patched files, rewrite references
os.rename(os.path.join(root, PLAT_CHUNK), os.path.join(root, NEW_PLAT))
os.rename(os.path.join(root, ENTRY), os.path.join(root, NEW_ENTRY))
for f in glob.glob(os.path.join(root, "**/*"), recursive=True):
    if not f.endswith((".js", ".html")) or not os.path.isfile(f):
        continue
    t = open(f, encoding="utf-8", errors="surrogateescape").read()
    u = t.replace("C2Xl4v4i5h2.js", "C2Xl4v4i5h2-amd4.js").replace("CQ-U_Vo4pO.js", "CQ-U_Vo4pO-amd4.js")
    if u != t:
        open(f, "w", encoding="utf-8", errors="surrogateescape").write(u)
print("patched OK, ROCm image:", ROCM_IMAGE)
