#!/usr/bin/env python3
"""Add the amd-gpu-passthrough platform (native NAI 2.8.1 enum value) (ROCm vLLM) to the NAI 2.8.1 nai-core chart.
Usage: patch-nai-amdgpu.py <path-to-unpacked-nai-core-chart>"""
import re, json, sys
chart = sys.argv[1]
ROCM = "{{ .Values.naiApi.supportedVLLMROCmImage }}:{{ .Values.naiApi.supportedVLLMROCmImageTag }}"

# 1. values.yaml: new ROCm image values, placed after the CUDA vLLM tag
vp = f"{chart}/values.yaml"
v = open(vp).read()
if "supportedVLLMROCmImage" not in v:
    anchor = '  supportedVLLMGPUImageTag: "v0.26.0-gpu"\n'
    assert anchor in v, "values anchor not found"
    v = v.replace(anchor, anchor +
        '  # [amd-gpu patch] ROCm vLLM image used for the amd-gpu-passthrough platform (Radeon Pro W7900, gfx1100)\n'
        '  supportedVLLMROCmImage: "localhost/nai-vllm-rocm"  # override with <private-registry>/nai-vllm-rocm\n'
        '  supportedVLLMROCmImageTag: "v0.29.0-rocm10.1.0"\n')
    open(vp, "w").write(v)

# 2. model_config.json: top-level vllmROCmImage + amd-gpu platform on every vllm runtime
cp = f"{chart}/templates/nai-components/nai-api/api-config-map.yaml"
s = open(cp).read()
m = re.search(r'  model_config\.json: \|\n(.*?)(?=\n  [A-Za-z_.-]+: \||\Z)', s, re.S)
d = json.loads(m.group(1))
nd = {}
for k, val in d.items():          # keep key order, insert after vllmCPUImage
    nd[k] = val
    if k == "vllmCPUImage":
        nd["vllmROCmImage"] = ROCM
for mod in nd["models"]:
    for r in mod["catalog"]["runtimes"]:
        if r["name"] == "vllm":
            r.setdefault("supportedPlatforms", {})["amd-gpu-passthrough"] = {"image": ROCM}
out = "\n".join("    " + l for l in json.dumps(nd, indent=4, ensure_ascii=False).split("\n"))
s = s[:m.start(1)] + out + s[m.start(1) + len(m.group(1).rstrip()):]
open(cp, "w").write(s)
print("patched", chart)
